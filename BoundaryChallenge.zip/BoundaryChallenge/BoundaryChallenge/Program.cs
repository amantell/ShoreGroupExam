﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoundaryChallenge
{
    class Program
    {
        static void Main(string[] args)
        {

            int[,] blob = new int[10, 10] {
                {0,0,0,0,0,0,0,0,0,0},
                {0,0,1,1,1,0,0,0,0,0},
                {0,0,1,1,1,1,1,0,0,0},
                {0,0,1,0,0,0,1,0,0,0},
                {0,0,1,1,1,1,1,0,0,0},
                {0,0,0,0,1,0,1,0,0,0},
                {0,0,0,0,1,0,1,0,0,0},
                {0,0,0,0,1,1,1,0,0,0},
                {0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0}
            };

            BlobEntity blobEntity = new BlobEntity();
            blobEntity.Initialize(blob);
            blobEntity.GetDimensions();

            Console.WriteLine(string.Format("Cell Reads: {0}", blobEntity.CellReads.ToString()));
            Console.WriteLine(string.Format("Top: {0}", blobEntity.Top.ToString()));
            Console.WriteLine(string.Format("Left: {0}", blobEntity.Left.ToString()));
            Console.WriteLine(string.Format("Bottom: {0}", blobEntity.Bottom.ToString()));
            Console.WriteLine(string.Format("Right: {0}", blobEntity.Right.ToString()));        
        }
    }

    class BlobEntity
    {
        private int[,] _blob;
        private int _top = -1;
        private int _left = -1;
        private int _bottom = -1;
        private int _right = -1;
        private int _cellReads = 0;

        public int Top { get { return _top; } }
        public int Left { get { return _left; } }
        public int Bottom { get{ return _bottom; } }
        public int Right { get { return _right; } }
        public int CellReads { get { return _cellReads; } }

        public void Initialize(int[,] blob) {
            this._blob = blob;
        }

        public void GetDimensions()
        {
            ValidateTop();
            ValidateLeft();
            ValidateBottom();
            ValidateRight();
        }

        private void ValidateTop() {
            for (int iCounter = 0; iCounter < this._blob.GetLength(0); iCounter++)
            {
                if (ValidateTop(iCounter)) break;
            }
        }

        private bool ValidateTop(int counter) {

            for (int iCounter = 0; iCounter < this._blob.GetLength(1); iCounter++)
            {
                if (this._blob[counter, iCounter] == 1)
                {
                    this._top = counter;
                    this._cellReads++;
                    return true;
                }
                this._cellReads++;
            }
            return false;
        }

        private void ValidateLeft()
        {
            for (int iCounter = 0; iCounter < this._blob.GetLength(0); iCounter++)
            {
                if (ValidateLeft(iCounter)) break;
            }
        }

        private bool ValidateLeft(int counter) {

            for (int iCounter = 0; iCounter < this._blob.GetLength(1); iCounter++)
            {
                if ((iCounter + 1) == this._blob.GetLength(1)) break;
                if (this._blob[counter, (iCounter + 1)] == 1)
                {
                    this._left = iCounter + 1;
                    this._cellReads++;
                    return true;
                }
                this._cellReads++;
            }
            return false;
        }

        private void ValidateBottom()
        {
            for (int iCounter = (this._blob.GetLength(0) - 1); iCounter >= 0; iCounter--)
            {
                if (ValidateBottom(iCounter)) break;
            }
        }

        private bool ValidateBottom(int counter) {

            for (int iCounter = 0; iCounter < this._blob.GetLength(1); iCounter++)
            {
                if (this._blob[counter, iCounter] == 1)
                {
                    this._bottom = counter + 2;
                    this._cellReads++;
                    return true;
                }
                this._cellReads++;
            }
            return false;
        }

        private void ValidateRight()
        {
            for (int iCounter = 0; iCounter < this._blob.GetLength(0); iCounter++)
            {
                ValidateRight(iCounter);
            }
        }

        private void ValidateRight(int counter)
        {
            for (int iCounter = (this._blob.GetLength(1) - 1); iCounter > 0; iCounter--)
            {
                if ((iCounter - 1) < 0) break;
                if (this._blob[counter, (iCounter - 1)] == 1)
                {
                    if (this._right == -1)
                    {
                        this._right = iCounter + 1;
                        this._cellReads++;
                        break;
                    }
                    else
                    {
                        if ((iCounter + 1) > this._right)
                        {
                            this._right = iCounter + 1;
                            this._cellReads++;
                            break;
                        }
                    }
                }
                this._cellReads++;
            }
        }
    }
}
